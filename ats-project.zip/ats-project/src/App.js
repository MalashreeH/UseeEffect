// import React, { useState } from 'react';
// import { BrowserRouter as Router, Route, Navigate } from 'react-router-dom';
// import LoginPage from './login/LoginPage';
// // import BuDashboard from './components/Bu_Manager/BuDashboard';
// // import TaDashboard from './components/Ta_Dashboard/TaDashboard';
// import BuDashboard2 from './components/Bu_Manager/BuDashboard2';
// import BuDashboard from './components/Bu_Manager/BuDashoard';
// import TaDashboard from './components/Tu_Manager/TuDashboard';


// function App() {
//   const [isLoggedIn, setIsLoggedIn] = useState(false);
//   const [userType, setUserType] = useState('');
//   console.log(userType)

//   const handleLogin = (selectedUserType) => {
//     // Simulate a successful login with a hardcoded username and password
//     const username = 'demo'; // Replace with your actual username
//     const password = 'demo'; // Replace with your actual password

//     // Replace this logic with your actual authentication process
//     if (selectedUserType === 'bu' && username === 'demo' && password === 'demo') {
//       setUserType('bu');
//       setIsLoggedIn(true);
//     } else if (selectedUserType === 'ta' && username === 'demo' && password === 'demo') {
//       setUserType('ta');
//       setIsLoggedIn(true);
//     } else {
//       alert('Login failed. Please check your credentials.');
//     }
//   };

//   return (
//     <Router>
//       <div className="App">
//         <Route exact path="/">
//           {isLoggedIn ? (
//             <Navigate to={`/${userType}-dashboard`} />
//           ) : (
//             <LoginPage handleLogin={handleLogin} />
//           )}
//         </Route>
      
//         <Route path="/login-page" component= {LoginPage} />
//         <Route path="/bu-dashboard" component={BuDashboard} />

//         <Route path="/ta-dashboard" component={TaDashboard} />
//         <Route path="/bu-dashboard2" component={BuDashboard2} />
        
//       </div>
//     </Router>
//   );
// }

// export default App;




import React, { useState } from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'; // Note the use of Routes here
import LoginPage from './login/LoginPage';
import BuDashboard2 from './components/Bu_Manager/BuDashboard2';
import BuDashboard from './components/Bu_Manager/BuDashoard';
import TaDashboard from './components/Tu_Manager/TuDashboard';
import AdminDashboard from './components/Admin/AdminDashboard';
import AddEmp from './components/Admin/AddEmp';
import Home from './components/Admin/Home';
import EditEmp from './components/Admin/EditEmp';
import ViewEmp from './components/Admin/ViewEmp';
import HomePage from './navbar/HomePage';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userType, setUserType] = useState('');

  const handleLogin = (selectedUserType) => {
    // Simulate a successful login with a hardcoded username and password
    const username = 'demo'; // Replace with your actual username
    const password = 'demo'; // Replace with your actual password

    // Replace this logic with your actual authentication process
    
    if (selectedUserType === 'aa' && username === 'demo' && password === 'demo') {
      setUserType('aa');
      setIsLoggedIn(true);
    }
    
      else if (selectedUserType === 'bu' && username === 'demo' && password === 'demo') {
      setUserType('bu');
      setIsLoggedIn(true);
    } else if (selectedUserType === 'ta' && username === 'demo' && password === 'demo') {
      setUserType('ta');
      setIsLoggedIn(true);
    } else {
      alert('Login failed. Please check your credentials.');
    }
  };

  return (
    <Router>
      {/* <HomePage/> */}
      <div className="App">

        <Routes> {/* Wrap your Route components in a Routes element */}
          <Route path="/" element={isLoggedIn ? <Navigate to={`/${userType}-dashboard`} /> : <LoginPage handleLogin={handleLogin} />} />
          <Route path="/login-page" element={<LoginPage handleLogin={handleLogin} />} />
          <Route path="/bu-dashboard" element={<BuDashboard />} />
          <Route exact path="/ta-dashboard" element={<TaDashboard />} />
          <Route  exact path="/bu-dashboard2" element={<BuDashboard2 />} />
          <Route exact path="/aa-dashboard" element={<AdminDashboard />} />
          <Route exact  path="/add-emp" element={<AddEmp/>} />
          <Route exact path="/home" element={<Home/>} />
          <Route exact path="/updateuser/:id" element={<EditEmp/>} />
          <Route exact path="/getuser/:id" element={<ViewEmp/>} />
          
          
          
          
        </Routes>
      </div>
    </Router>
  );
}

export default App;
