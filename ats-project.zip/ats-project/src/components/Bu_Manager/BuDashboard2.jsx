// import React, { useState } from "react";
// import "./BuDashboard.css";
// import {Link} from 'react-router-dom'

// function BuDashboard2() {
//   const [formData, setFormData] = useState({
//     rrDate: "",
//     projectName: "",
//     division: "",
//     resourceStartDate: "",
//     requestorName: "",
//     designation: "",
//     contactNumber: "",
//     email: "",
//     experienceLevel: "",
//     jobDescription: "",
//     ctcOfferDetails: "",
//     workLocation: "",
//   });

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData({
//       ...formData,
//       [name]: value,
//     });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     // You can handle form submission logic here, e.g., send the data to an API
//     console.log(formData);
//   };

//   return (
//     <div className="form-container ">
//       <h2>Raise a Request </h2>
//       <form onSubmit={handleSubmit}>
//         <div className="form-group ">
//           <label>RR Date:</label>
//           <input
//             type="date"
//             name="rrDate"
//             value={formData.rrDate}
//             onChange={handleChange}
//             required
//           />
//         </div>

//         <div className="form-group">
//           <label>Project Name:</label>
//           <input
//             type="text"
//             name="projectName"
//             placeholder="Project Name"
//             value={formData.projectName}
//             onChange={handleChange}
//             required
//           />
//         </div>

//         <div className="form-group">
//   <label>Division:</label>
//   <select
//     name="division"
//     value={formData.division}
//     onChange={handleChange}
//     required
//     className="form-control" // Add Bootstrap's form-control class
//     style={{ width: '100%', height:'50px',padding:'16px',borderRadius:'5px' }} // Set the width to 100%
//   >
//     <option value="">Select Division</option>
//     <option value="IT">IT</option>
//     <option value="Infra">Infra</option>
//     <option value="ERP">ERP</option>
//   </select>
// </div>



//         <div className="form-group">
//           <label>Resource Start Date:</label>
//           <input
//             type="date"
//             name="resourceStartDate"
//             value={formData.resourceStartDate}
//             onChange={handleChange}
//             required
//           />
//         </div>

//         <div className="form-group">
//           <label>Requestor Name:</label>
//           <input
//             type="text"
//             name="requestorName"
//             placeholder="Requestor Name"
//             value={formData.requestorName}
//             onChange={handleChange}
//             required
//           />
//         </div>

//         <div className="form-group">
//           <label>Designation:</label>
//           <input
//             type="text"
//             name="designation"
//             value={formData.designation}
//             onChange={handleChange}
//             required
//           />
//         </div>

//         <div className="form-group">
//           <label>Contact Number:</label>
//           <input
//             type="text"
//             name="contactNumber"
//             value={formData.contactNumber}
//             onChange={handleChange}
//             required
//           />
//         </div>

//         <div className="form-group">
//           <label>Email ID:</label>
//           <input
//             type="email"
//             name="email"
//             value={formData.email}
//             onChange={handleChange}
//             required
//           />
//         </div>

//         <div className="form-group">
//           <label>Experience:</label>
//           <input
//             type="text"
//             name="experienceLevel"
//             value={formData.experienceLevel}
//             onChange={handleChange}
//             required
//           />
//         </div>

//         <div className="form-group">
//           <label>Job Description:</label>
//           <textarea
//             name="jobDescription"
//             value={formData.jobDescription}
//             onChange={handleChange}
//             required
//           ></textarea>
//         </div>

//         <div className="form-group">
//           <label>CTC:</label>
//           <input
//             type="text"
//             name="ctcOfferDetails"
//             value={formData.ctcOfferDetails}
//             onChange={handleChange}
//             required
//           />
//         </div>

//         <div className="form-group">
//           <label>Work-Location:</label>
//           <input
//             type="text"
//             name="workLocation"
//             value={formData.workLocation}
//             onChange={handleChange}
//             required
//           />
//         </div>

//         <button type="submit">Submit</button>
//         <Link to="/bu-dashboard">
//       <button className='btn-right'>Back</button>
//       </Link>
//       <Link to="/login-page">
//       <button className='btn-right'>Logout</button>
//       </Link>
//       </form> 
//     </div>
//   );
// }

// export default BuDashboard2;


// import React, { useState } from "react";
// const BuDashboard2 = () => {
//   const [formData, setFormData] = useState({
//         rrDate: "",
//         projectName: "",
//         division: "",
//         resourceStartDate: "",
//         requestorName: "",
//         designation: "",
//         contactNumber: "",
//         email: "",
//         experienceLevel: "",
//         jobDescription: "",
//         ctcOfferDetails: "",
//         workLocation: "",
//       });
//       const handleChange = (e) => {
//             const { name, value } = e.target;
//             setFormData({
//               ...formData,
//               [name]: value,
//             });
//           };
//             const handleSubmit = (e) => {
//     e.preventDefault();
//     // You can handle form submission logic here, e.g., send the data to an API
//     console.log(formData);
//   };
//   return (
//     <div className='container'>
//       <form action="">
//         <input type="text" placeholder='Enter project name' />
//       </form>
//     </div>
//   )
// }

// export default BuDashboard2



import React from 'react';
import {
  MDBBtn,
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBRow,
  MDBCol,
  MDBInput,
  MDBSelect
}
from 'mdb-react-ui-kit';

function BuDashboard2() {
  return (
    <MDBContainer fluid>

      <MDBRow className='d-flex justify-content-center align-items-center'>

        <MDBCol lg='8'>

          <MDBCard className='my-5 rounded-3' style={{maxWidth: '600px'}}>
            <MDBCardImage src='https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img3.webp' className='w-100 rounded-top'  alt="Sample photo"/>

            <MDBCardBody className='px-5'>

              <h3 className="mb-4 pb-2 pb-md-0 mb-md-5 px-md-2">Registration Info</h3>
              <MDBInput wrapperClass='mb-4' label='Name' id='form1' type='text'/>

              <MDBRow>

                <MDBCol md='6'>
                  <MDBInput wrapperClass='datepicker mb-4' label='Select a date' id='form2' type='text'/>
                </MDBCol>

                <MDBCol md='6' className='mb-4'>
                  <MDBSelect
                    data={[
                      { text: 'Gender', value: 1, disabled: true },
                      { text: 'Female', value: 2 },
                      { text: 'Male', value: 3 }
                    ]}
                    />
                </MDBCol>

              </MDBRow>

              <MDBSelect
                className='mb-4'
                data={[
                  { text: 'Class', value: 1, disabled: true },
                  { text: 'Class 1', value: 2 },
                  { text: 'Class 2', value: 3 },
                  { text: 'Class 3', value: 3 }
                ]}
                />

              <MDBRow>
                <MDBCol md='6'>
                  <MDBInput wrapperClass='mb-4' label='Registration code' id='form3' type='text'/>
                </MDBCol>
              </MDBRow>

              <MDBBtn color='success' className='mb-4' size='lg'>Submit</MDBBtn>

            </MDBCardBody>
          </MDBCard>

        </MDBCol>
      </MDBRow>

    </MDBContainer>
  );
}

export default BuDashboard2;