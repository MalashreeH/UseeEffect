

import React from 'react'
import {Link} from "react-router-dom"
// import "./bu.css"
const BuDashboard = () => {
  return (
    <div className='btn' >
      <Link to="/bu-dashboard2">
      <button className='btn-right'>Raise a request</button>
      </Link>
    </div>
  )
}

export default BuDashboard
