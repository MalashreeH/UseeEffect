import React, { useEffect, useState } from 'react'
import { Outlet,Link, } from 'react-router-dom'

import style from "./admin.module.css"

const AdminMainBar = () => {

  return (
    <div id={style.adminmainbar}>
      <marquee direction="right">  <h1>Welcome to AdminDashboard</h1></marquee>
      {/* <div className="card" style={{height:"300px", width:"500px"}} border>
      <h2>Number of Employess</h2>
      
      </div> */}
     
      <ul>
        <Link to="/login-page">
        <li >Logout</li>
        </Link>
      </ul>
     
      <Outlet/>
    </div>
  )
}

export default AdminMainBar