// import axios from "axios";
// import React, { useEffect,useState } from "react";
// import { Link, useParams } from "react-router-dom";

// export default function ViewEmp() {
//   const [user, setUser] = useState({
//     id:"",
//     name: "",
//     email: "",
//     description:"",
//     contactno:"",
//     address:"",
//     roles:""


//   });

//   const { id } = useParams();

//   useEffect(() => {
//     loadUser();
//   }, [id]);

// //   const loadUser = async () => {
// //     const result = await axios.get(`http://localhost:9090/user/api/getuser/${id}`);
// //     setUser(result.data);
// //     console.log(user);
// //   };


// const loadUser = async () => {
//     try {
//       const result = await axios.get(`http://localhost:9090/user/api/getuser/${id}`);
//       setUser(result.data);
//       console.log(result.data); // Use result.data instead of user
//     } catch (error) {
//       console.error(error);
//     }
//   };
  

//   return (
//     <div className="container">
//       <div className="row">
//         <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
//           <h2 className="text-center m-4">User Details</h2>

//           <div className="card">
            
//             <div className="card-header">
//               Details of user id : {user.id}
//               <ul className="list-group list-group-flush">
//                 <li className="list-group-item">
//                   <b>Name:</b>
//                   {user.name}
//                 </li>
//                 {/* <li className="list-group-item">
//                   <b>UserName:</b>
//                   {user.username}
//                 </li> */}
//                 <li className="list-group-item">
//                   <b>Email:</b>
//                   {user.email}
//                 </li>
//                 <li className="list-group-item">
//                   <b>Description:</b>
//                   {user.description}
//                 </li>
//                 <li className="list-group-item">
//                   <b>Contact-no:</b>
//                   {user.contactno}
//                 </li>
//                 <li className="list-group-item">
//                   <b>Address:</b>
//                   {user.address}
//                 </li>
//                 <li className="list-group-item">
//                   <b>Role:</b>
//                   {user.roles}
//                 </li>
//               </ul>
//             </div>
//           </div>
//           <Link className="btn btn-primary my-2" to={"/aa-dashboard"}>
//             Back to Home
//           </Link>
//         </div>
//       </div>
//     </div>
//   );
// }



import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

export default function ViewEmp() {
  const [user, setUser] = useState({
    id: "",
    name: "",
    email: "",
    description: "",
    contactno: "",
    address: "",
    roles: ""
  });

  const { id} = useParams();
  const [error, setError] = useState(null);
  useEffect(() => {
    
    let fetchdata=async()=>{
      try{
        let {data}= await axios.get(`http://localhost:9090/user/api/getuser/${id}`)
        console.log(data.data);
            setUser(data.data)
            console.log(data);
            console.log(user,"hiii");
          }
          catch{
      console.log(error);
          }
    }
    fetchdata();
   
  },[])

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4">User Details</h2>

          <div className="card">
            <div className="card-header">
              Details of user id : {user.userId}
              <ul className="list-group list-group-flush">
                <li className="list-group-item">
                  <b>Name:</b>
                  {user.name}
                </li>
                <li className="list-group-item">
                  <b>Email:</b>
                  {user.email}
                </li>
                <li className="list-group-item">
                  <b>Description:</b>
                  {user.description}
                </li>
                <li className="list-group-item">
                  <b>Contact-no:</b>
                  {user.contactno}
                </li>
                <li className="list-group-item">
                  <b>Address:</b>
                  {user.address}
                </li>
                <li className="list-group-item">
                  <b>Role:</b>
                  {user.roles}
                </li>
              </ul>
            </div>
          </div>
          <Link className="btn btn-primary my-2" to={"/aa-dashboard"}>
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
