import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function AddUser() {
  let navigate = useNavigate();

  const [user, setUser] = useState({
   
    name: "",
    // username: "",
    email: "",
    password: "",
    description: "",
    contactno: "",
    address: "",
    roles: "",
    isactive: "",
  });

  const [errors, setErrors] = useState({});

  const {
   
    name,
    email,
    password,
    description,
    contactno,
    address,
    roles,
    
  } = user;

  const onInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };
  const validateForm = () => {
    const errors = {};

    if (!name.trim()) {
      errors.name = "Name is required";
    }

    if (!email.trim()) {
      errors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = "Email is invalid";
    }

    if (!password.trim()) {
      errors.password = "Password is required";
    }

    if (!description.trim()) {
      errors.description = "Description is required";
    }

    if (!contactno.trim()) {
      errors.contactno = "Contact Number is required";
    }

    if (!address.trim()) {
      errors.address = "Address is required";
    }

    if (!roles.trim()) {
      errors.roles = "Roles is required";
    }


    setErrors(errors);

    return Object.keys(errors).length === 0;
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    if (validateForm()) {
      await axios.post("http://localhost:9090/user/api/createuser", user);
      navigate("/");
    }
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4">Register User</h2>

          <form onSubmit={(e) => onSubmit(e)}>
            
            <div className="mb-3" >
              <label htmlFor="Name" className="form-label">
                Name 
              </label>
              <input
                type="text"
                className={`form-control ${errors.name ? "is-invalid" : ""}`}
                placeholder="Enter your name"
                name="name"
                value={name}
                onChange={(e) => onInputChange(e)}
              />
              {errors.name && <div className="invalid-feedback">{errors.name}</div>}
            </div>
            {/* <div className="mb-3">
              <label htmlFor="Username" className="form-label">
                Username
              </label>
              <input
                type="text"
                className="form-control"
                placeholder="Enter your username"
                name="username"
                value={username}
                onChange={(e) => onInputChange(e)}
              />
            </div> */}
            <div className="mb-3">
              <label htmlFor="Email" className="form-label">
                E-mail
              </label>
              <input
                type="text"
                className={`form-control ${errors.email ? "is-invalid" : ""}`}
                placeholder="Enter your e-mail address"
                name="email"
                value={email}
                onChange={(e) => onInputChange(e)}
              />
              {errors.email && <div className="invalid-feedback">{errors.email}</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="Password" className="form-label">
                Password
              </label>
              <input
                type="password"
                className={`form-control ${errors.password ? "is-invalid" : ""}`}
                placeholder="Enter password"
                name="password"
                value={password}
                onChange={(e) => onInputChange(e)}
              />
              {errors.password && <div className="invalid-feedback">{errors.password}</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="Description" className="form-label">
                Description
              </label>
              <input
                type="text"
                className={`form-control ${errors.description ? "is-invalid" : ""}`}
                placeholder="Enter description"
                name="description"
                value={description}
                onChange={(e) => onInputChange(e)}
              />
              {errors.description && <div className="invalid-feedback">{errors.description}</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="ContactNo" className="form-label">
                Contact No
              </label>
              <input
                type="text"
                className={`form-control ${errors.contactno ? "is-invalid" : ""}`}
                placeholder="Enter contact number"
                name="contactno"
                value={contactno}
                onChange={(e) => onInputChange(e)}
              />
              {errors.contactno && <div className="invalid-feedback">{errors.contactno}</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="Address" className="form-label">
                Address
              </label>
              <input
                type="text"
                className={`form-control ${errors.address ? "is-invalid" : ""}`}
                placeholder="Enter address"
                name="address"
                value={address}
                onChange={(e) => onInputChange(e)}
              />
              {errors.address && <div className="invalid-feedback">{errors.address}</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="Roles" className="form-label">
                Role
              </label>
              <input
                type="text"
                className={`form-control ${errors.roles ? "is-invalid" : ""}`}
                placeholder="Enter roles"
                name="roles"
                value={roles}
                onChange={(e) => onInputChange(e)}
              />
              {errors.roles && <div className="invalid-feedback">{errors.roles}</div>}
            </div>
            
              <div className="div "  style={{ display: 'flex', alignItems: 'center' }}>
            <button type="submit" className="btn btn-outline-primary">
              Submit
            </button>
            <Link className="btn btn-outline-danger mx-2" to="/">
              Cancel
            </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
