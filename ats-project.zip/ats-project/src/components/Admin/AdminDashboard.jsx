
// import 'bootstrap/dist/css/bootstrap.min.css';
// // import "./../Admin/AdminDashboard.css"
// import React from 'react';
// import { Link } from 'react-router-dom';

// function AdminDashboard() {
//   return (
//     <div className="App">
//       <nav className="navbar navbar-expand-lg bg-body-tertiary " >
//         <div className="container-fluid">
//           <button
//             className="navbar-toggler"
//             type="button"
//             data-bs-toggle="collapse"
//             data-bs-target="#navbarTogglerDemo01"
//             aria-controls="navbarTogglerDemo01"
//             aria-expanded="false"
//             aria-label="Toggle navigation"
//           >
//             <span className="navbar-toggler-icon"></span>
//           </button>
//           <a className="navbar-brand" href="#">
//             ATS project
//           </a>
//           <ul className="navbar-nav me-auto mb-2 mb-lg-0">
//             <li className="nav-item">
//               <a className="nav-link active" aria-current="page" href="#">
                
//               </a>
//             </li>
//             <li className="nav-item">
//               <a className="nav-link" href="/view-emp">
//               View-Employee
//               </a>
//             </li>
//             <li className="nav-item">
//               <a className="nav-link" href="#">
//                 Delete-Employee
//               </a>
//             </li>
//             <li className="nav-item">
//               <a className="nav-link" href="/edit-emp">
//                 Edit-Employee
//               </a>
//             </li>
//             <li className="nav-item">
//               <a className="nav-link" href="/home">
//                 Home
//               </a>
//             </li>
//           </ul>
//           <form className="d-flex">
//             {/* <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"> */}
//             <Link to="/add-emp">
//             <button className="btn btn-outline-success" type="submit">
//               Add Employee
//             </button></Link>
//           </form>
//         </div>
//       </nav>

//       {/* Add your page content below the navbar */}
//       <div className="container">
   
//       </div>
//     </div>
//   );
// }

// export default AdminDashboard;

import React from 'react'
import AdminSidebar from './AdminSidebar'
import AdminMainBar from './AdminMainBar'
import style from "./admin.module.css"
import Navbar from './../../navbar/Navbar';


const AdminDashBoard = () => {
  return (
    <div id={style.admindashboard}>
      
      <AdminSidebar/>
      <AdminMainBar/>
      {/* <Navbar/> */}
    </div>
  )
}

export default AdminDashBoard
