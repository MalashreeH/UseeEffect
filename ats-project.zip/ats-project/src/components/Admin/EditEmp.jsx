import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

export default function EditEmp() {
  let navigate = useNavigate();

  const { id } = useParams();


  const [user, setUser] = useState({
    id: "",
    name: "",
    username: "",
    email: "",
    password: "",
    description: "",
    contactno: "",
    address: "",
    roles: "",
    isactive: "",
  });

  // const { name, username, email } = user;
  const [errors, setErrors] = useState({});

  const {
    
    name,
    email,
    password,
    description,
    contactno,
    address,
    roles,
    
  } = user;
  const onInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };
  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.put(`http://localhost:9090/user/api/updateuser/${id}`, user);
    navigate("/");
  };

  useEffect(() => {
    
    let fetchdata=async()=>{
      try{
        let {data}= await axios.get(`http://localhost:9090/user/api/getuser/${id}`)
        console.log(data.data);
            setUser(data.data)
            console.log(data);
            console.log(user,"hiii");
          }
          catch{
      console.log(errors);
          }
    }
    fetchdata();
   
  },[])
  

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4">Edit User</h2>

          <form onSubmit={(e) => onSubmit(e)}>
            <div className="mb-3">
              <label htmlFor="Name" className="form-label">
                Name
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter your name"
                name="name"
                value={name}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            
    
            <div className="mb-3">
              <label htmlFor="Email" className="form-label">
                E-mail
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter your e-mail address"
                name="email"
                value={email}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Password" className="form-label">
                Password
              </label>
              <input
                type="password"
                className={`form-control ${errors.password ? "is-invalid" : ""}`}
                placeholder="Enter password"
                name="password"
                value={password}
                onChange={(e) => onInputChange(e)}
              />
              {errors.password && <div className="invalid-feedback">{errors.password}</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="Description" className="form-label">
                Description
              </label>
              <input
                type="text"
                className={`form-control ${errors.description ? "is-invalid" : ""}`}
                placeholder="Enter description"
                name="description"
                value={description}
                onChange={(e) => onInputChange(e)}
              />
              {errors.description && <div className="invalid-feedback">{errors.description}</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="ContactNo" className="form-label">
                Contact No
              </label>
              <input
                type="text"
                className={`form-control ${errors.contactno ? "is-invalid" : ""}`}
                placeholder="Enter contact number"
                name="contactno"
                value={contactno}
                onChange={(e) => onInputChange(e)}
              />
              {errors.contactno && <div className="invalid-feedback">{errors.contactno}</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="Address" className="form-label">
                Address
              </label>
              <input
                type="text"
                className={`form-control ${errors.address ? "is-invalid" : ""}`}
                placeholder="Enter address"
                name="address"
                value={address}
                onChange={(e) => onInputChange(e)}
              />
              {errors.address && <div className="invalid-feedback">{errors.address}</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="Roles" className="form-label">
                Role
              </label>
              <input
                type="text"
                className={`form-control ${errors.roles ? "is-invalid" : ""}`}
                placeholder="Enter roles"
                name="roles"
                value={roles}
                onChange={(e) => onInputChange(e)}
              />
              {errors.roles && <div className="invalid-feedback">{errors.roles}</div>}
            </div>
            
            <div className="div "  style={{ display: 'flex', alignItems: 'center' }}>
            <button type="submit" className="btn btn-outline-primary">
              Submit
            </button>
            <Link className="btn btn-outline-danger mx-2" to="/aa-dashboard">
              Cancel
            </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}