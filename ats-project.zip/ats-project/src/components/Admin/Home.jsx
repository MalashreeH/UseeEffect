// // import React, { useEffect, useState } from "react";
// // import axios from "axios";
// // import { Link, useParams } from "react-router-dom";



// // export default function Home() {
 
// //   const [users, setUsers] = useState([]);

// //   const { id } = useParams();

// //   useEffect(() => {
// //     loadUsers();
// //   }, []);

// //   useEffect(() => {
// //     loadUsers();
// //   }, []);
  
// //   const loadUsers = () => {
// //     axios.get("http://localhost:9090/user/api/getallusers",)
// //       .then((response) => {
// //         const usersArray = Object.values(response.data);
// //         setUsers(usersArray);
// //         console.log(usersArray);
// //       })
// //       .catch((error) => {
// //         console.error("Error loading users:", error);
// //       });
// //   };
  

// //   const deleteUser = async (id) => {
// //     await axios.delete(`http://localhost:9090/user/api/deleteuser/${id}`);
// //     loadUsers();
// //   };

// //   return (
// //     <div className="container">
// //       <div className="py-4">
// //         <table className="table border shadow">
// //           <thead>
// //             <tr>
// //               <th scope="col">ID</th>
// //               <th scope="col">Job-ID</th>
// //               <th scope="col">Name</th>
// //               <th scope="col">Email</th>
// //               <th scope="col">Description</th>
// //               <th scope="col">Contactno</th>
// //               <th scope="col">Address</th>
// //               <th scope="col">Role</th>
// //             </tr>
// //           </thead>
// //           <tbody>
// //             {users.map((user, index) => (
// //               <tr key={user.id}>
// //                 <th >
// //                   {index + 1}
// //                 </th>
// //                 <td>{user.id}</td>
// //                 <td>{user.name}</td>
// //                 <td>{user.email}</td>
// //                 <td>{user.description}</td>
// //                 <td>{user.contactno}</td>
// //                 <td>{user.address}</td>
// //                 <td>{user.roles}</td>
// //                 <td>{user.isactive}</td>

// //                 <td>
// //                   <Link
// //                     className="btn btn-primary mx-2"
// //                     to={`/view-emp/${user.id}`}
// //                   >
// //                     View
// //                   </Link>
// //                   <Link
// //                     className="btn btn-outline-primary mx-2"
// //                     to={`/edit-emp/${user.id}`}
// //                   >
// //                     Edit
// //                   </Link>
// //                   <button
// //                     className="btn btn-danger mx-2"
// //                     onClick={() => deleteUser(user.id)}
// //                   >
// //                     Delete
// //                   </button>
// //                 </td>
// //               </tr>
// //             ))}
// //           </tbody>
// //         </table>
// //       </div>
// //     </div>
// //   );
// // }

// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { Link, useParams } from "react-router-dom";

// export default function Home() {
//   const [users, setUsers] = useState([]);
//   const [deleteData, setDeleteData] = useState([]);
//   const { id } = useParams();
//   const [loading, setLoading] = useState(true); // Track loading state
//   const [error, setError] = useState(null); // Track errors

//   useEffect(() => {
    
//     let fetchdata=async()=>{
//       try{
//         let {data}= await axios.get("http://localhost:9090/user/api/getallusers")
//         console.log(data.data);
//             setUsers(data.data)
//             console.log(data);
//             console.log(users,"hiii");
//           }
//           catch{
//       console.log(error);
//           }
//     }
//     fetchdata();
   
//   },[])
  
  
//   //   axios
//   //     .get("http://localhost:9090/user/api/getallusers")
//   //     .then((response) => {
//   //       const usersArray = Object.values(response.data);
//   //       setUsers(usersArray);
//   //       console.log(usersArray);
//   //       console.log(users);
//   //       setLoading(false); // Set loading to false when data is loaded
//   //     })
//   //     .catch((error) => {
//   //       console.error("Error loading users:", error);
//   //       setError("Error loading users. Please try again later.");
//   //       setLoading(false); // Set loading to false in case of error
//   //     });
//   // },[])

  

//   const deleteUser = async (id,user) => {
//     try{
//      await axios.delete(`http://localhost:9090/user/api/deleteuser/${id}`);
//     // setDeleteData(user)
//   } 
//     catch{
//       console.log(error);
//     }
//   };

//   return (
//     <div className="container">
//       <div className="py-4">
        
//           <table className="table border shadow">
//            <thead>
//   <tr>
//     <th scope="col">ID</th>
//     <th scope="col">Name</th>
//     <th scope="col">Email</th>
//     <th scope="col">Description</th>
//     <th scope="col">Contactno</th>
//     <th scope="col">Address</th>
//     <th scope="col">Role</th>
//     <th scope="col">Action</th>
//     {/* Add other table header cells */}
//   </tr>
// </thead>

//             <tbody>
           
//               {users.map((user) => (
                
//                 <tr key={user.id}>
//                   <th scope="row">{user.id}</th>
//                   <td>{user.id}</td>
//                   <td>{user.name}</td>
//                   <td>{user.email}</td>
                 
//                   <td>{user.description}</td>
//                   <td>{user.contactno}</td>
//                   <td>{user.address}</td>
//                   <td>{user.roles}</td>
                  
//                   <td>
//                     <Link
//                       className="btn btn-primary mx-2"
//                       to={`/getuser/${user.id}`}
//                     >
//                       View
//                     </Link>
//                     <Link
//                       className="btn btn-outline-primary mx-2"
//                       to={`/updateuser/${user.id}`}
//                     >
//                       Edit
//                     </Link>
//                     <button
//                       className="btn btn-danger mx-2"
//                       onClick={() => deleteUser(user.id,user)}
//                     >
//                       Delete
//                     </button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
        
//       </div>
//     </div>
//   );
// }



import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";

export default function Home() {
  const [users, setUsers] = useState([]);
  const { id } = useParams();

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      const response = await axios.get("http://localhost:9090/user/api/getallusers");
      setUsers(response.data.data);
    } catch (error) {
      console.error("Error loading users:", error);
    }
  };

  const deleteUser = async (id) => {
    try {
      await axios.delete(`http://localhost:9090/user/api/deleteuser/${id}`);
      // After successful delete, reload the users
      loadUsers();
    } catch (error) {
      console.log("Error deleting user:", error);
    }
  };

  return (
    <div className="container">
      <div className="py-4">
        <table className="table border shadow">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Description</th>
              <th scope="col">Contactno</th>
              <th scope="col">Address</th>
              <th scope="col">Role</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <th scope="row">{user.id}</th>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.description}</td>
                <td>{user.contactno}</td>
                <td>{user.address}</td>
                <td>{user.roles}</td>
                <td>
                  <Link
                    className="btn btn-primary mx-2"
                    to={`/getuser/${user.id}`}
                  >
                    View
                  </Link>
                  <Link
                    className="btn btn-outline-primary mx-2"
                    to={`/updateuser/${user.id}`}
                  >
                    Edit
                  </Link>
                  <button
                    className="btn btn-danger mx-2"
                    onClick={() => deleteUser(user.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

