import React from 'react'
import {Link} from "react-router-dom"
import style  from "./admin.module.css"


const AdminSidebar = () => {
  return (
    <div id={style.sidebarcontainer}>
        <h2>Sidebar</h2>
        <div id={style.sidebarlist}>
        <ul>
  <li><Link to="/add-emp"><span>Add Employee</span></Link></li>
  <li><Link to="/home"><span>View Employee</span></Link></li>
  <div className="menu-spacer"></div> {/* Spacer */}
  <li><Link to="/home"><span>View BU_Managers</span></Link></li>
  <li><Link to="/home"><span>View TA_Manager</span></Link></li>
  <li><Link to="/home"><span>View Recruiter</span></Link></li>

{/* <li><Link to="/admindashboard/viewacademytable"><span>View acadamy</span></Link></li>
            <li><Link to="/admindashboard/viewbranch"><span>View Branch</span></Link></li>
            <li><Link to="/admindashboard"><span>View Course</span></Link></li>
            <li><Link to="/"><span>Home</span></Link></li> */}
        </ul>
        </div>
    </div>
  )
}

export default AdminSidebar