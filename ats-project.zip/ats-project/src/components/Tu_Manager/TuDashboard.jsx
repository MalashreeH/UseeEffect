import React from 'react';

function TaDashboard() {
  return (
    <div>
      <h2>Welcome to the TaDashboard</h2>
      {/* Add your user dashboard content here */}
    </div>
  );
}

export default TaDashboard;
