import React, { useState } from 'react';
import './LoginPage.css';
import logo from "./../components/Images/logo.png"
import Navbar from './../navbar/Navbar';


function LoginPage({ handleLogin }) {
  const [selectedUserType, setSelectedUserType] = useState('');
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    handleLogin(selectedUserType);
  };
    
  return (
    <>
    <Navbar/>
    <div className="login-container ">
      <img src={logo} alt="Logo" className="logo" />
      <form className="login-form" onSubmit={handleSubmit}>
        <h2>Login</h2> 
        <div className="form-group">
          <select
            className='inp'
            id="userType"
            name="userType"
            value={selectedUserType}
            onChange={(e) => setSelectedUserType(e.target.value)}
          >
            <option value="/">Select User Type</option>
            <option value="aa">Admin</option>
            <option value="bu">BU MANAGER</option>
            <option value="ta">TA MANAGER</option>
            <option value="rr">Recruiter </option>
          </select>
        </div>
        <div className="form-group">
          <input
            type="text"
            id="username"
            name="username"
            value={formData.username}
            onChange={handleInputChange}
            required
            placeholder="Enter your username"
          />
        </div>
        <div className="form-group">
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleInputChange}
            required
            placeholder="Enter your password"
          />
        </div>
        <button type="submit">Login</button>
      </form>
    </div>
    </>
  );
}

export default LoginPage;
