import React from 'react'
import Menu from './Menu';
import style from "./_navbar.module.css"
import Logoats from './Logoats';



const Navbar = () => {
  return (
    <section id={style.navbar}>
        <article>
       <Logoats/>
            <Menu/>
        </article>
    </section>
  )
}

export default Navbar