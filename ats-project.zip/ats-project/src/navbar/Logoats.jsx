import React from 'react'
import style from "./_navbar.module.css"

const Logoats = () => {
  return (
    <div>
        <h1 id={style.logo}>ATS project</h1>
    </div>
  )
}

export default Logoats