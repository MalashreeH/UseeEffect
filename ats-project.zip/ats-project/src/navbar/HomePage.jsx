import React from 'react'
import Navbar from './Navbar'

const HomePage = () => {
  return (
    <div>
        <h1>Welcome to ATS PROJECT</h1>
        <Navbar/>
    </div>
  )
}

export default HomePage